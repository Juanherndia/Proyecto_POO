package CapaGrafica;

import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class PrimeraVentana extends Application {

    @Override
    public void start(Stage ventana) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/CapaGrafica/VentanaFXML1.fxml")); //Arma la ventana con el XML
        Scene scene = new Scene(root);
        ventana.setScene(scene);
        ventana.setTitle("DATOS CLIENTES");
        ventana.setResizable(false); // No se puede cambiar el tamaño de la ventana
        //ventana.setOnCloseRequest(event -> {event.consume();});
        ventana.show(); //Muestra la ventana
    }

    public static void main(String[] args) {
        launch(args);
    }
    public void funcion(){
        launch();
    }

}
