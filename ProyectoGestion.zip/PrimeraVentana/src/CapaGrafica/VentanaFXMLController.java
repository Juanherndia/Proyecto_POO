package CapaGrafica;


import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import primeraventana.mainFX1;
import primeraventana.Cliente;

public class VentanaFXMLController implements Initializable {


    // Atributos agregados por Gabriel Soche
    private int np = 0;
    @FXML
    private GridPane matriz_cliente;
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    } 
    @SuppressWarnings("unchecked")
    @FXML
    private void modelarClientes(){
        Label id = new Label("                   ID");
        Label nombre = new Label("            NOMBRE");
        Label telefono = new Label("          TELEFONO");
        Label email = new Label("                EMAIL");
        
        matriz_cliente.add(id, 0, 0);
        matriz_cliente.add(nombre, 1, 0);
        matriz_cliente.add(telefono, 2, 0);
        matriz_cliente.add(email, 3, 0);
        
        id.setStyle("-fx-font-family: 'Microsoft JhengHei'; -fx-font-weight: bold");
        nombre.setStyle("-fx-font-family: 'Microsoft JhengHei'; -fx-font-weight: bold");
        telefono.setStyle("-fx-font-family: 'Microsoft JhengHei'; -fx-font-weight: bold");
        email.setStyle("-fx-font-family: 'Microsoft JhengHei'; -fx-font-weight: bold");
        
        ArrayList<Cliente> clientes = mainFX1.datosClientes();
        
        for(int i =0; i < clientes.size();i++){
            String idCliente = Integer.toString(clientes.get(i).getId());
            String nombreCliente = clientes.get(i).getNombre();
            String telefonoCliente = clientes.get(i).getTelefono();
            String emailCliente = clientes.get(i).getEmail();
            
            Label labelID = new Label(idCliente);
            Label labelNombre = new Label(nombreCliente);
            Label labelTelefono = new Label(telefonoCliente);
            Label labelEmail = new Label(emailCliente);
            
            matriz_cliente.add(labelID, 0, i + 1);            
            matriz_cliente.add(labelNombre, 1, i + 1);
            matriz_cliente.add(labelTelefono, 2, i + 1);
            matriz_cliente.add(labelEmail, 3, i + 1);
        }
    }

    @FXML
    private void salida(ActionEvent event) {
    }
}
