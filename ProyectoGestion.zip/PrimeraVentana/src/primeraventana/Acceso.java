package primeraventana;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import static primeraventana.mainFX1.datosBibliotecarios;
import static primeraventana.mainFX1.datosClientes;
import static primeraventana.mainFX1.salir;

public class Acceso {
    //Esta mal ya que solo compara el primer cliente
    public void verificarAccesoCliente() {
    String nombreCliente = JOptionPane.showInputDialog("Ingrese su nombre:");
    ArrayList<Cliente> compararDatosClientes = datosClientes();
    boolean clienteEncontrado = false;
    for (Cliente cliente : compararDatosClientes) {
        if (cliente.getNombre().equalsIgnoreCase(nombreCliente)) {
            clienteEncontrado = true;
            System.out.println("Bienvenido, cliente");
            break;
        }
        else{
            System.out.println("Nombre incorrecto");
            salir();
        }
    }
    }
    public void verificarAccesoBibliotecario() {
    int idIngresadoBibliotecario = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su contraseña:"));

    ArrayList<Bibliotecario> compararDatosBibliotecarios = datosBibliotecarios();

    boolean BibliotecarioEncontrado = false;
    for (Bibliotecario cliente : compararDatosBibliotecarios) {
        if (cliente.getContrasena() == idIngresadoBibliotecario) {
            BibliotecarioEncontrado = true;
            System.out.println("Bienvenido, bibliotecario ");
            break;
        }
        else{
            System.out.println("Contrasena incorrecta");
            salir();
        }
    }
    }
    public Acceso(){

}
}
