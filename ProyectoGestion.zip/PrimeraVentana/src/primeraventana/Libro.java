
package primeraventana;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Libro {
    // Atributos
    private int idLibro;
    private String titulo;
    private String autor;
    private String genero;
    private int anioPublicacion;
    private char estado; 
    
    //Contructor
    public Libro(int idLibro, String titulo, String autor, String genero, int anioPublicacion, char estado, int cliente){
    if (idLibro <= 0 && anioPublicacion > 2024) {
            System.out.println("Id no valido y año equivocado");
    } 
        this.idLibro = idLibro;
        this.titulo = titulo;
        this.autor = autor;
        this.genero = genero;
        this.anioPublicacion = anioPublicacion;
        this.estado = estado; //Cada libro nuevo aparecera como disponible
    }
    //Constructor vacio
    public Libro(){
    
    }
    //Metodos
    
    public void getInformacion(Libro libroConsulta) {
        JOptionPane.showMessageDialog(null, 
            "ID: " + libroConsulta.getIdLibro() + "\n" +
            "Titulo: " + libroConsulta.getTitulo() + "\n" +
            "Autor: " + libroConsulta.getAutor() + "\n" +
            "Género: " + libroConsulta.getGenero() + "\n" +
            "Anio de Publicacion: " + libroConsulta.getAnioPublicacion() + "\n" +
            "Estado: " + libroConsulta.getEstado());
    }
    
    //Libros disponibles llegan a la funcion pedirPrestado
    public void prestarLibro() {
        this.setEstado('P');
    }
    public void imprimirLibro(){
        System.out.println("LIBRO:" + this.idLibro + "," + this.titulo + "," + this.autor + "," + this.genero + "," + this.anioPublicacion + "," + this.estado);
    }

    public void reservarLibro(Libro libro, ArrayList<Libro> libros) {
        int libroReserva = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el Id del libro que quiere reservar"));
        for (int i = 0; i < libros.size(); i++) {
            if (libroReserva == libros.get(i).getIdLibro()) {
                if (libros.get(i).getEstado() == 'D') { // Verificar si el libro está disponible
                    libros.get(i).setEstado('R'); // Cambiar el estado del libro a "reservado"
                    JOptionPane.showMessageDialog(null, "El libro " + libros.get(i).getTitulo() + " lo has reservado.");
                    return;
                }
                else if (libros.get(i).getEstado() == 'P') { // Verificar si el libro está disponible
                    libros.get(i).setEstado('R'); // Cambiar el estado del libro a "reservado"
                    JOptionPane.showMessageDialog(null, "El libro " + libros.get(i).getTitulo() + " lo has reservado.");
                    return;
                }
                else {
                    JOptionPane.showMessageDialog(null, "El libro " + libros.get(i).getTitulo() + " no está disponible para reservar en este momento.");
                    return;
                }
            }
        }
        JOptionPane.showMessageDialog(null, "No se encontró ningún libro con el ID.");
    }

    public void devolverLibro() {
        this.setEstado('D');
    }

    //Getter y setter
    public int getIdLibro() {
        
        return this.idLibro;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public void setAnioPublicacion(int anioPublicacion) {
        this.anioPublicacion = anioPublicacion;
    }

    public char getEstado() {
        return estado;
    }

    public void setEstado(char estado) {
        this.estado = estado;
    }
}