package primeraventana;
// Importación de la clase ArrayList 
import java.util.ArrayList;
import javax.swing.JOptionPane;

// Declaración de la clase Cliente que hereda el atributo nombre y id de la clase Persona
public class Cliente extends Persona{
    // Atributos de la clase Cliente
    private String telefono; // Número de teléfono del cliente
    private String email; // Dirección de correo electrónico del cliente
    private ArrayList<Libro> prestamo = new ArrayList<Libro>(); // Lista de libros prestados al cliente
    private ArrayList<Libro> reserva = new ArrayList<Libro>(); // Lista de libros reservados por el cliente
    
    // Constructor de la clase Cliente que inicializa los atributos idCliente, nombre, telefono y email
    public Cliente(int id, String nombre, String telefono, String email) {
        super(nombre, id);
        this.telefono = telefono; 
        this.email = email;
    }
    
    // Constructor vacío de la clase Cliente
    public Cliente(){
    }
    
    // Método para realizar un préstamo de un libro al cliente
    public void realizarPrestamo(Libro libro, ArrayList<Libro> listaLibrosDisponibles) {
        int libroPedido = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el Id del libro que quiere pedir prestado"));
        for (int i = 0; i < listaLibrosDisponibles.size(); i++) {  
            if(libroPedido == listaLibrosDisponibles.get(i).getIdLibro()){
                if(listaLibrosDisponibles.get(i).getEstado() == 'D'){
                    listaLibrosDisponibles.get(i).prestarLibro();
                    System.out.println("El libro ha sido prestado al usuario" );
                    prestamo.add(libro); // Agrega el libro a la lista de prestamos
                    break;
                }
                else{
                    System.out.println("No esta disponible ese libro");
                }
            }else{
                System.out.println("No existe ese libro");
            }
        }
    }

    // Método para realizar la devolución de un libro por parte del cliente
    public void realizarDevolucion(Libro libro, ArrayList<Libro> listaLibrosDisponibles) {
        int libroDevuelto = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el Id del libro que quiere devolver"));
        for (int i = 0; i < listaLibrosDisponibles.size(); i++) {  
            if(libroDevuelto == listaLibrosDisponibles.get(i).getIdLibro()){
                if(listaLibrosDisponibles.get(i).getEstado() == 'P'){
                    listaLibrosDisponibles.get(i).devolverLibro();
                    System.out.println("El libro ha sido devuelto" );
                    prestamo.remove(libro); // Elimina el libro de la lista de préstamos
                    break;
                }
                else{
                    System.out.println("No esta prestado ese libro");
                }
            }   
        }
    }
    
    // Método para consultar los libros prestados al cliente
    public void consultarLibrosPrestados(ArrayList<Libro> listaLibros) {
        for (int i = 0; i < listaLibros.size(); i++) {
            if(listaLibros.get(i).getEstado() == 'P'){
               listaLibros.get(i).imprimirLibro();
            }
        }
    }
    
    // Método para consultar los libros reservados por el cliente
    public void consultarLibrosReservados(ArrayList<Libro> listaLibros) {
        for (int i = 0; i < listaLibros.size(); i++) {
            if(listaLibros.get(i).getEstado() == 'R'){
               listaLibros.get(i).imprimirLibro();
            }
        }
    }
    // Getters y setters para los atributos privados de la clase Cliente
    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
