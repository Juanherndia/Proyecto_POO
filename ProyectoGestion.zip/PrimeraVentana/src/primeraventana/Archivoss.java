package primeraventana;

import java.io.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Archivoss {
    
    public static void createFile(String nameFile){
        File file = new File(nameFile);
        //Se usa try y catch para crear el archivo y evitar errores de codigo
        try {
            PrintWriter output = new PrintWriter(file);
            output.close();
            System.out.println("El archivo ha sido creado!");
        } catch (FileNotFoundException ex){
            ex.printStackTrace(System.out);
        }
    }
    // Método para leer archivos
    public static void leerArchivo() {

        // Leer contenido del archivo "Libros.txt"
        String linea1 = readFromFile("Libros.txt");
        System.out.println("["+linea1+"]");
        
        // Leer contenido del archivo "Clientes.txt"
        String linea2 = readFromFile("Clientes.txt");
        System.out.println("["+linea2+"]");
        
        // Leer contenido del archivo "Bibliotecario.txt"
        String linea3 = readFromFile("Bibliotecario.txt");
        System.out.println("["+linea3+"]");
    }
    
    // Método para limpiar un archivo
    public static void clearFile(String nombreArchivo) {
        try (FileWriter fw = new FileWriter(nombreArchivo, false);
             BufferedWriter bw = new BufferedWriter(fw)) {
            
            bw.write(""); // Escribir una cadena vacía para limpiar el archivo
            
        } catch (IOException miError) {
            System.out.println("Error al limpiar el archivo " + nombreArchivo);
            System.out.println(miError.getMessage());
        }
    }
    
    // Método para escribir en el archivo "Libro"
    public static boolean writeToFile1(String nombreArchivo, ArrayList<Libro> listaLibros) {
        try (FileWriter fw = new FileWriter(nombreArchivo, true);
             BufferedWriter bw = new BufferedWriter(fw)) {
            
            // Recorrer la lista de libros y escribir cada libro en una nueva línea
            for (Libro libro : listaLibros) {
                String linea = "Id libro: " + libro.getIdLibro() + " , " +
                               "Titulo: " + libro.getTitulo() + " , " +
                               "Autor: " + libro.getAutor() + " , " +
                               "Genero: " + libro.getGenero() + " , " +
                               "Año publicacion: " + libro.getAnioPublicacion();
                bw.write(linea);
                bw.newLine(); // Escribir una nueva línea después de cada libro
            }
            
            return true; // Indicar que la escritura fue exitosa
            
        } catch (IOException miError) {
            System.out.println("Error en la escritura del archivo");
            System.out.println(miError.getMessage());
            return false; // Indicar que hubo un error en la escritura
        }
    }
    
    // Método para escribir en el archivo "Cliente"
    public static boolean writeToFile2(String nombreArchivo, ArrayList<Cliente> listaClientes) {
        try (FileWriter fw = new FileWriter(nombreArchivo, true);
             BufferedWriter bw = new BufferedWriter(fw)) {
            
            // Recorrer la lista de clientes y escribir cada cliente en una nueva línea
            for (Cliente cliente : listaClientes) {
                String linea = "Id cliente: " + cliente.getId() + " , " +
                               "Nombre: " + cliente.getNombre() + " , " +
                               "Telefono: " + cliente.getTelefono() + " , " +
                               "Email: " + cliente.getEmail();
                bw.write(linea);
                bw.newLine(); // Escribir una nueva línea después de cada cliente
            }
            
            return true; // Indicar que la escritura fue exitosa
            
        } catch (IOException miError) {
            System.out.println("Error en la escritura del archivo");
            System.out.println(miError.getMessage());
            return false; // Indicar que hubo un error en la escritura
        }
    }
    
    // Método para escribir en el archivo "Bibliotecario"
    public static boolean writeToFile3(String nombreArchivo, ArrayList<Bibliotecario> listaBibliotecarios) {
        try (FileWriter fw = new FileWriter(nombreArchivo, true);
             BufferedWriter bw = new BufferedWriter(fw)) {
            
            // Recorrer la lista de bibliotecarios y escribir cada bibliotecario en una nueva línea
            for (Bibliotecario bibliotecario : listaBibliotecarios) {
                String linea = "Nombre:" + bibliotecario.getNombre() + " , " +
                               "Usuario: " + bibliotecario.getUsuario() + " , " +
                               "Contraseña: " + bibliotecario.getContrasena();
                bw.write(linea);
                bw.newLine(); // Escribir una nueva línea después de cada bibliotecario
            }
            
            return true; // Indicar que la escritura fue exitosa
            
        } catch (IOException miError) {
            System.out.println("Error en la escritura del archivo");
            System.out.println(miError.getMessage());
            return false; // Indicar que hubo un error en la escritura
        }
    }
    
    // Método para leer contenido de un archivo
    public static String readFromFile(String archivo) {
        try (FileReader fr = new FileReader(archivo);
             BufferedReader br = new BufferedReader(fr)) {
            
            String text = br.readLine(); // Leer la primera línea del archivo
            return text; // Devolver la línea leída
            
        } catch (IOException miError) {
            System.err.println("Error al leer el archivo");
            System.out.println(miError.getMessage());
            return null; // Indicar que hubo un error en la lectura
        }
    }
}
