
package primeraventana;

import java.util.ArrayList;
import javax.swing.JOptionPane;

// Declaración de la clase Bibliotecario que hereda el atributo nombre de la clase Persona
public class Bibliotecario extends Persona {
    // Atributos
    private String usuario;
    private int contrasena;

    // Constructor
    public Bibliotecario(int id, String nombre, String usuario, int contrasena) {
        super(nombre, id);
        this.usuario = usuario;
        this.contrasena = contrasena;
    }
    public Bibliotecario (){
        
    }
    // Método para registar un libro, este llamada a la clase libro y toma los atributos de esta
    public Libro registrarLibro(Libro libro) {
        //Se empiezan a pedir los datos del libro que se desea agregar por parte del bibliotecario
        int id = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el Id del libro:"));
        libro.setIdLibro(id);
        String titulo = JOptionPane.showInputDialog("Ingrese el titulo del libro:");
        libro.setTitulo(titulo);
        String autor = JOptionPane.showInputDialog("Ingrese el autor del libro:");
        libro.setAutor(autor);
        String genero = JOptionPane.showInputDialog("Ingrese el genero del libro:");
        libro.setGenero(genero);
        int anioPublicacio = Integer.parseInt(JOptionPane.showInputDialog("Ingrese anio de publicacion"));
        libro.setAnioPublicacion(anioPublicacio);
        libro.setEstado('D');
        return libro;
    }
    
    //Esta mal
    public String consultarInformacionLibro(Libro libroConsulta, ArrayList<Libro> listaLibrosDisponibles) {
        int idLibro = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el Id del libro que quiere consultar"));
        for (int i = 0; i < listaLibrosDisponibles.size(); i++) {  
            if(idLibro == listaLibrosDisponibles.get(i).getIdLibro()){
               listaLibrosDisponibles.get(i);
               libroConsulta.getInformacion(listaLibrosDisponibles.get(i));
               libroConsulta.setEstado('P');
               break;
            }
        }return "No se encontró información para el libro con ID " + idLibro;
    }
    public String eliminarLibro(Libro libroConsulta1, ArrayList<Libro> listaLibrosDisponibles) {
        int idLibro = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el Id del libro que quiere eliminar"));
        for (int i = 0; i < listaLibrosDisponibles.size(); i++) {  
            if(idLibro == listaLibrosDisponibles.get(i).getIdLibro()){
               listaLibrosDisponibles.get(i);
               libroConsulta1.getInformacion(listaLibrosDisponibles.get(i));
               listaLibrosDisponibles.remove(listaLibrosDisponibles.get(i));
               break;
            }
        }return "No se encontró información para el libro con ID " + idLibro;
    }

    public void obtenerLibrosDisponibles(ArrayList<Libro> listaLibros) {
         for (int i = 0; i < listaLibros.size(); i++) {
            if(listaLibros.get(i).getEstado() == 'D'){
                listaLibros.get(i).imprimirLibro();
            }
        }
    }

    public void obtenerLibrosPrestados(ArrayList<Libro> listaLibros) {
       for (int i = 0; i < listaLibros.size(); i++) {
            if(listaLibros.get(i).getEstado() == 'P'){
                listaLibros.get(i).imprimirLibro();
            }
        }
    }
    
    public void obtenerLibrosReservados(ArrayList<Libro> listaLibros1) {
       for (int i = 0; i < 10; i++) {
            if(listaLibros1.get(i).getEstado() == 'R'){
                listaLibros1.get(i).imprimirLibro();
            }
        }
    }


    // Métodos adicionales para modificar atributos si es necesario
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setContrasena(int contrasena) {
        this.contrasena = contrasena;
    }

    public String getUsuario() {
        return usuario;
    }

    public int getContrasena() {
        return contrasena;
    }
}