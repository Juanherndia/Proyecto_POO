package MenuPrincipal;



import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Menu1 extends Application {

    @Override
    public void start(Stage menu) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/Menu.fxml")); //Arma la ventana con el XML
        Scene scene = new Scene(root);
        menu.setScene(scene);
        menu.setTitle("MENU");
        menu.setResizable(false); // No se puede cambiar el tamaño de la ventana
        //ventana.setOnCloseRequest(event -> {event.consume();});
        menu.show(); //Muestra la ventana
    }

    public static void main(String[] args) {
        launch(args);
    }

}
